<?php

namespace App\Models;

use \Carbon\Carbon;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
  protected $table = 'projects';

  protected $fillable = [
    'name', 'slug', 'publish', 'image', 'content', 'category_id',
    'set_title', 'meta_key', 'meta_desc', 'view'
  ];

  public function category () {
    return $this->belongsTo('App\Models\Category');
  }

  public function setSlugAttribute ( $string ) {
    $slug = str_slug( $string );
    $this->attributes['slug'] = $slug;
  }

  public function getCreatedAtAttribute( $value ) {
    return Carbon::parse($value)->format('d/m/Y H:i');
  }
}
